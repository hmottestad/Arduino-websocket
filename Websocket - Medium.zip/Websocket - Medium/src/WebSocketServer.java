
import org.webbitserver.BaseWebSocketHandler;
import org.webbitserver.WebSocketConnection;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class WebSocketServer extends BaseWebSocketHandler {

	//TODO - Du trenger en liste for å holde oversikt over tilkoblede klienter. Eg ArrayList eller en HashMap.

	public void onOpen(WebSocketConnection connection) {
		/*
		TODO
		Legg til connection i listen over tilkoblede klienter.
		Tips. Lage en debug utskrift.
		*/
	}

	public void onClose(WebSocketConnection connection) {
		/*
		TODO
		Fjern connection fra listen.
		*/

	}


	public void onMessage(final WebSocketConnection connection, String message) {

		/*

		TODO
		Ta imot beskjed fra websocket.
		Send en beskjed til Arduino, bruk gjerne sendToArduino();

		*/

	}


	static void sendToArudino(int i) {

		/*
		TODO
		Send til arduino.
		Bruk Controller.arduinoSerialUSB.output.write(...);
		Bruk byte array.

		Tips. Her er det veldig nyttig med debug utskrift.
		*/

	}


	public static void notifyAllClients(String value) {
		/*
		TODO
		Iterer gjennom alle tilkoblede klienter og send beskjed til de med connection.send(...)

		*/

	}
}
